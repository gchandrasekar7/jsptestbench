package com.chandru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsptestbenchApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsptestbenchApplication.class, args);
	}

}
