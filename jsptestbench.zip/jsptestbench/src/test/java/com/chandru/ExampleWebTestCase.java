package com.chandru;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import net.sourceforge.jwebunit.junit.WebTester;

public class ExampleWebTestCase {
	   @Test
	    //Start to write our test method.
	    public void swTestAcademyTitleTest() {
	 
	        //Step 1- Driver Instantiation: Instantiate driver object as FirefoxDriver
	        WebDriver driver = new ChromeDriver();
	 
	        //Step 2- Navigation: Open a website
	        driver.navigate().to("http://localhost:8080/login");
	 
	        //Step 3- Assertion: Check its title is correct
	        //assertEquals method Parameters: Expected Value, Actual Value, Assertion Message
	        assertEquals("First Web Application", driver.getTitle());
	 
	        //Step 4- Close Driver
	        driver.close();
	 
	        //Step 5- Quit Driver
	        driver.quit();
	    }
	}